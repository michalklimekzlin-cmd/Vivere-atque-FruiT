# VaF'ii'T · Glyph Canvas PWA

Samostatná minimalistická PWA jako základní tapeta/plátno pro pozdější vložení do CHT 360°‰.

## Nasazení na GitHub Pages
1. Nahraj všechny čtyři soubory (`index.html`, `manifest.json`, `service-worker.js`, `icon.svg`) do jedné složky v repozitáři.
2. Pokud ji nasazuješ jako kořen GitHub Pages, otevři stránku HTTPS a v Safari zvol **Sdílet → Přidat na plochu**.
3. Pokud ji dáváš do podsložky, všechny cesty jsou relativní (`./`), takže zůstávají uvnitř podsložky.

## Ovládání
- Jeden prst: otočení do všech směrů.
- Dva prsty: přiblížení/oddálení; síť se mění společně s měřítkem a její střed zůstává zarovnaný s Glyph.
- Dvojité klepnutí: přepnutí mezi třemi připravenými Glyphy.
- Plátno se samo pomalu otáčí proti směru hodinových ručiček.
- Service worker ukládá základní soubory pro offline použití po první návštěvě.

## Poznámky
- Jde o samostatný prototyp plátna, nikoli o napojení na CHT 360°‰ nebo existující paměť VaF'ii'T.
- Glyph zůstává jediným prvkem ve středu sítě. Žádné další VaF'ii'T se negenerují.
