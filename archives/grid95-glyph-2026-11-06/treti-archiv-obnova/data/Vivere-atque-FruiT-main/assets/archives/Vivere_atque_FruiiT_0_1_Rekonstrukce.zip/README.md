# Vivere atque Fru`ii´T 0.1

Rekonstruovaný vstupní bod repozitáře.
Po otevření index.html lze procházet všechny nalezené moduly projektu.
