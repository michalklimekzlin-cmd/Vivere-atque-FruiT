// simple placeholder for vaft hub
console.log("VAFT hub loaded - placeholder");
