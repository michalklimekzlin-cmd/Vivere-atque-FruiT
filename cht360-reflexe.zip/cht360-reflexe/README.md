# Reflexe •ア | CHT 360°‰

Nová, čistá PWA pro vědomé denní kroky (semínka).

## Co to je
- Offline-first
- Ukládá do `localStorage` pod klíčem `cht360_reflexe_v1`
- Posílá událost `cht.reflexe.changed` přes BroadcastChannel `cht360_relay_v1`
- Respektuje principy CHT 360: Batole pouze pozoruje, Paměť se nepřepisuje automaticky
- Čtyři jádra (Země, Jazyk, Hra, Řízení)
- Dark + gold estetika podle design systému CHT

## Jak spustit
1. Otevři `index.html` v prohlížeči (nebo nahraj celou složku na jakýkoliv static hosting).
2. Můžeš si ji nainstalovat jako PWA (Add to Home Screen).
3. Funguje i bez internetu.

## Co dál můžeme dělat
- Most do Batole (čtení veřejného stavu)
- Tlačítko „Poslat do Paměti“ (vědomý krok)
- Export semínek jako JSON / glyph
- Napojení na Revii nebo ChybaŽrouta
- Vizuální timeline podle jader

Vytvořeno jako hmatatelný první krok.
